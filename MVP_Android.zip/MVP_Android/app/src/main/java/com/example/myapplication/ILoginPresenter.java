package com.example.myapplication;

public interface ILoginPresenter {

    void doLogin(String userName, String passwordd);
    void setProgressBarVisiblity(int visiblity);
}
