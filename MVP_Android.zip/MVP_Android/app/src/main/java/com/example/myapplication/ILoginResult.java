package com.example.myapplication;

public interface ILoginResult {

    public void onLoginResult(Boolean result, int code);
    public void onSetProgressBarVisibility(int visibility);
}
